// ** MUI Imports
import { BadgeProps } from '@mui/material/Badge'

export type CustomBadgeProps = BadgeProps & { skin?: 'light' }
